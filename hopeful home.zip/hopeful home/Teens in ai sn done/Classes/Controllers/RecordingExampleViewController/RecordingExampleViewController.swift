//
//  RecordingExampleViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class RecordingExampleViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var audioPlayerView: UIView!
    @IBOutlet weak var trackView: UIView!
    @IBOutlet weak var fillView: UIView!
    @IBOutlet weak var oval2View: UIView!
    @IBOutlet weak var remainingLabel: UILabel!
    @IBOutlet weak var currentLabel: UILabel!
    @IBOutlet weak var trackTwoView: UIView!
    @IBOutlet weak var songTitleLabel: UILabel!
    @IBOutlet weak var monday13thLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup audioPlayerView
        self.audioPlayerView.layer.cornerRadius = 13
        self.audioPlayerView.layer.masksToBounds = true
        
        // Setup trackView
        self.trackView.layer.cornerRadius = 1.5
        self.trackView.layer.masksToBounds = true
        
        // Setup fillView
        self.fillView.layer.cornerRadius = 1.5
        self.fillView.layer.masksToBounds = true
        
        // Setup oval2View
        self.oval2View.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.16).cgColor /* #000000 */
        self.oval2View.layer.shadowOffset = CGSize(width: 0, height: 5)
        self.oval2View.layer.shadowRadius = 10
        self.oval2View.layer.shadowOpacity = 1
        
        self.oval2View.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.03).cgColor /* #000000 */
        self.oval2View.layer.borderWidth = 0.5
        
        self.oval2View.layer.cornerRadius = 10
        self.oval2View.layer.masksToBounds = true
        
        // Setup remainingLabel
        let remainingLabelAttrString = NSMutableAttributedString(string: "-4:13", attributes: [
            .font : UIFont.systemFont(ofSize: 13),
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 0.97),
            .kern : 0.9,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.remainingLabel.attributedText = remainingLabelAttrString
        
        // Setup currentLabel
        let currentLabelAttrString = NSMutableAttributedString(string: "0:12", attributes: [
            .font : UIFont.systemFont(ofSize: 13),
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 0.97),
            .kern : 0.9,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.currentLabel.attributedText = currentLabelAttrString
        
        // Setup trackTwoView
        self.trackTwoView.layer.cornerRadius = 1.5
        self.trackTwoView.layer.masksToBounds = true
        
        // Setup songTitleLabel
        let songTitleLabelAttrString = NSMutableAttributedString(string: "Monday 13th", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 0.99),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.songTitleLabel.attributedText = songTitleLabelAttrString
        
        // Setup monday13thLabel
        let monday13thLabelAttrString = NSMutableAttributedString(string: "Monday 13th", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.monday13thLabel.attributedText = monday13thLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Recordings Library", sender: nil)
    }
}
