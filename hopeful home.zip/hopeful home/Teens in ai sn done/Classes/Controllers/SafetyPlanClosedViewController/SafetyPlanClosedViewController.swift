//
//  SafetyPlanClosedViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class SafetyPlanClosedViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var httpsLrsbOrgUkLabel: UILabel!
    @IBOutlet weak var althoughLeavingIsLabel: UILabel!
    @IBOutlet weak var whatIsASafetyPlaLabel: UILabel!
    @IBOutlet weak var accordingToReducinLabel: UILabel!
    @IBOutlet weak var keyPointsAndYourLabel: UILabel!
    @IBOutlet weak var dropdownButton: SupernovaButton!
    @IBOutlet weak var safetyContigencyPlLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!
    @IBOutlet weak var thisSectionWillHeLabel: UILabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup httpsLrsbOrgUkLabel
        let httpsLrsbOrgUkLabelAttrString = NSMutableAttributedString(string: "https://lrsb.org.uk/uploads/making-a-safety-plan.pdf", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.httpsLrsbOrgUkLabel.attributedText = httpsLrsbOrgUkLabelAttrString
        
        // Setup althoughLeavingIsLabel
        let althoughLeavingIsLabelAttrString = NSMutableAttributedString(string: "\nAlthough leaving is a big courageous thing, statistics show that once a person leaves, the level of danger that they are in doubles because the perpetrator would be angry as they no longer have control over the situation, This may be one of the things stopping victims from leaving.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.althoughLeavingIsLabel.attributedText = althoughLeavingIsLabelAttrString
        
        // Setup whatIsASafetyPlaLabel
        let whatIsASafetyPlaLabelAttrString = NSMutableAttributedString(string: "What is a safety plan?", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.whatIsASafetyPlaLabel.attributedText = whatIsASafetyPlaLabelAttrString
        
        // Setup accordingToReducinLabel
        let accordingToReducinLabelAttrString = NSMutableAttributedString(string: "According to reducingtherisk.org.uk, A safety plan is a tool to assist in identifying options and evaluating them, and can limit the harm brought both to the victim and their children.\n\nVisit:", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.44, green: 0.44, blue: 0.44, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.accordingToReducinLabel.attributedText = accordingToReducinLabelAttrString
        
        // Setup keyPointsAndYourLabel
        let keyPointsAndYourLabelAttrString = NSMutableAttributedString(string: "Key Points and your survival kit", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.keyPointsAndYourLabel.attributedText = keyPointsAndYourLabelAttrString
        
        // Setup dropdownButton
        self.dropdownButton.snImageTextSpacing = 10
        
        // Setup safetyContigencyPlLabel
        let safetyContigencyPlLabelAttrString = NSMutableAttributedString(string: "Safety/Contigency Plans", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.safetyContigencyPlLabel.attributedText = safetyContigencyPlLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
        // Setup thisSectionWillHeLabel
        let thisSectionWillHeLabelAttrString = NSMutableAttributedString(string: "This section will help you understand safe routes and contingency plans that different charities and businesses have organised to help victims get leave safely", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 16)!,
            .foregroundColor : UIColor(red: 0.39, green: 0.62, blue: 0.72, alpha: 1),
            .kern : 0.17,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.thisSectionWillHeLabel.attributedText = thisSectionWillHeLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Safety Plan Open", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helpful Information", sender: nil)
    }
}
