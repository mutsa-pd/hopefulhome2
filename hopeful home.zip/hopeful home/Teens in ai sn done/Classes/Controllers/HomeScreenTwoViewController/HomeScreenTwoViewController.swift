//
//  HomeScreenTwoViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class HomeScreenTwoViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var helplineShortcutButton: SupernovaButton!
    @IBOutlet weak var overlayView: UIView!
    @IBOutlet weak var labelLabel: UILabel!
    @IBOutlet weak var labelTwoLabel: UILabel!
    @IBOutlet weak var labelThreeLabel: UILabel!
    @IBOutlet weak var xLabel: UILabel!
    @IBOutlet weak var πLabel: UILabel!
    @IBOutlet weak var welcomeLabel: SupernovaLabel!
    @IBOutlet weak var diaryShortcutButton: SupernovaButton!
    @IBOutlet weak var duringTheseUnknowiLabel: UILabel!
    @IBOutlet weak var feedbackButton: SupernovaButton!
    @IBOutlet weak var sendUsFeedbackToLabel: UILabel!
    @IBOutlet weak var clickToReturnToCButton: SupernovaButton!
    private var allGradientLayers: [CAGradientLayer] = []


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup helplineShortcutButton
        self.helplineShortcutButton.layer.cornerRadius = 6
        self.helplineShortcutButton.layer.masksToBounds = true
        self.helplineShortcutButton.snImageTextSpacing = 10
        
        // Setup overlayView
        let overlayViewGradient = CAGradientLayer()
        overlayViewGradient.colors = [UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */, UIColor(red: 0.847, green: 0.847, blue: 0.847, alpha: 0).cgColor /* #D8D8D8 */]
        overlayViewGradient.locations = [0, 1]
        overlayViewGradient.startPoint = CGPoint(x: 0.5, y: 0.778)
        overlayViewGradient.endPoint = CGPoint(x: 0.5, y: 1.511)
        overlayViewGradient.frame = self.overlayView.bounds
        self.overlayView.layer.insertSublayer(overlayViewGradient, at: 0)
        self.allGradientLayers.append(overlayViewGradient)
        
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "7", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "5", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup xLabel
        let xLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.xLabel.attributedText = xLabelAttrString
        
        // Setup πLabel
        let πLabelAttrString = NSMutableAttributedString(string: "1", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.πLabel.attributedText = πLabelAttrString
        
        // Setup welcomeLabel
        let welcomeLabelAttrString = NSMutableAttributedString(string: "Welcome", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 36)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.welcomeLabel.attributedText = welcomeLabelAttrString
        
        // Setup diaryShortcutButton
        self.diaryShortcutButton.layer.cornerRadius = 6
        self.diaryShortcutButton.layer.masksToBounds = true
        self.diaryShortcutButton.snImageTextSpacing = 10
        
        // Setup duringTheseUnknowiLabel
        let duringTheseUnknowiLabelAttrString = NSMutableAttributedString(string: "During these unknowing times, domestic abuse and abuse in general has rocketed to its peaks, to the point where helplines are being called 700% more. This is due to our current lockdown and stressful situations and more arguments that are taking place in the household.\nHopeful Home works towards making everyone’s house a safe and a healthy place to work and live, with the outside world not being safe anymore, we aim to make the home a safe environment for as many as we can.\nTake a look at our many features that we have to make you stronger day by day. Talk to Haven - the chatbot. Read our information on safety plans and legalities to empower yourself. Feed yourself from the many positive quotes we have on the app. Chat to our ai bots, to feel comforted and not alone.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 16)!,
            .foregroundColor : UIColor(red: 0.61, green: 0.61, blue: 0.61, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.duringTheseUnknowiLabel.attributedText = duringTheseUnknowiLabelAttrString
        
        // Setup feedbackButton
        self.feedbackButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor /* #000000 */
        self.feedbackButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.feedbackButton.layer.shadowRadius = 4
        self.feedbackButton.layer.shadowOpacity = 1
        
        self.feedbackButton.layer.borderColor = UIColor(red: 0.471, green: 0.624, blue: 0.8, alpha: 1).cgColor /* #789FCC */
        self.feedbackButton.layer.borderWidth = 2
        
        self.feedbackButton.snImageTextSpacing = 10
        
        // Setup sendUsFeedbackToLabel
        let sendUsFeedbackToLabelAttrString = NSMutableAttributedString(string: "Send us Feedback \nto help improve our app!", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.54,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.sendUsFeedbackToLabel.attributedText = sendUsFeedbackToLabelAttrString
        
        // Setup clickToReturnToCButton
        self.clickToReturnToCButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Layout

    override public func viewDidLayoutSubviews()  {
        super.viewDidLayoutSubviews()
        for layer in self.allGradientLayers {
            layer.frame = layer.superlayer?.frame ?? CGRect.zero
        }
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onIphoneCard3Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helplines", sender: nil)
    }

    @IBAction public func onAndroidCardPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push iPhone 11 Pro Max", sender: nil)
    }

    @IBAction public func onRectanglePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Feedback", sender: nil)
    }

    @IBAction public func onClickToReturnToCPressed(_ sender: UIButton)  {
    
    }
}
