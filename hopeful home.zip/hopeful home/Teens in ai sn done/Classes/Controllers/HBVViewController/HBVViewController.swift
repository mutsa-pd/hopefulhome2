//
//  HBVViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class HBVViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var honourBasedVioleLabel: UILabel!
    @IBOutlet weak var motivesForViolenceLabel: UILabel!
    @IBOutlet weak var dropdownButton: SupernovaButton!
    @IBOutlet weak var honourBasedViolencLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup honourBasedVioleLabel
        let honourBasedVioleLabelAttrString = NSMutableAttributedString(string: "\"'Honour based violence' is a crime or incident which has or may have been committed to protect or defend the honour of the family and/or community.\"\nIt is when a family member, for the pride of the family, decides to hard or abuse another person in the family. For example, it could be because they lost their virginity before they were married and so they would be abused.\n", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 21)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.23,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.honourBasedVioleLabel.attributedText = honourBasedVioleLabelAttrString
        
        // Setup motivesForViolenceLabel
        let motivesForViolenceLabelAttrString = NSMutableAttributedString(string: "Motives for violence", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 21)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.23,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.motivesForViolenceLabel.attributedText = motivesForViolenceLabelAttrString
        
        // Setup dropdownButton
        self.dropdownButton.snImageTextSpacing = 10
        
        // Setup honourBasedViolencLabel
        let honourBasedViolencLabelAttrString = NSMutableAttributedString(string: "Honour Based Violence", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.honourBasedViolencLabel.attributedText = honourBasedViolencLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push HBV Open", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push FGM & H", sender: nil)
    }
}
