//
//  FGMViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class FGMViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var femaleGenitalMutilLabel: UILabel!
    @IBOutlet weak var oftenForReligionLabel: UILabel!
    @IBOutlet weak var typesOfFgmLabel: UILabel!
    @IBOutlet weak var dropDownButton: SupernovaButton!
    @IBOutlet weak var fgmLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup femaleGenitalMutilLabel
        let femaleGenitalMutilLabelAttrString = NSMutableAttributedString(string: "Female genital mutilation (FGM) involves the partial or total removal of external female genitalia or other injury to the female genital organs for non-medical reasons OFTEN", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.39, green: 0.62, blue: 0.72, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.femaleGenitalMutilLabel.attributedText = femaleGenitalMutilLabelAttrString
        
        // Setup oftenForReligionLabel
        let oftenForReligionLabelAttrString = NSMutableAttributedString(string: "Often for religion, hygiene, preservation of virginity, marriageability and enhancement of male sexual pleasure.\n\nFGM can cause severe bleeding and problems urinating, and later cysts, infections, as well as complications in childbirth and increased risk of newborn deaths.\n\nMore than 200 million girls and women alive today have been cut in 30 countries in Africa, the Middle East and Asia where FGM is concentrated (1).\nFGM is mostly carried out on young girls between infancy and age 15.\nFGM is a violation of the human rights of girls and women.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.44, green: 0.44, blue: 0.44, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.oftenForReligionLabel.attributedText = oftenForReligionLabelAttrString
        
        // Setup typesOfFgmLabel
        let typesOfFgmLabelAttrString = NSMutableAttributedString(string: "Types of FGM", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 21)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.23,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.typesOfFgmLabel.attributedText = typesOfFgmLabelAttrString
        
        // Setup dropDownButton
        self.dropDownButton.snImageTextSpacing = 10
        
        // Setup fgmLabel
        let fgmLabelAttrString = NSMutableAttributedString(string: "FGM", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.fgmLabel.attributedText = fgmLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push FGM Open", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push FGM & H", sender: nil)
    }
}
