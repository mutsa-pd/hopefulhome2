//
//  CSEViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class CSEViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var childSexualAbuseLabel: SupernovaLabel!
    @IBOutlet weak var whatIsChildSexualLabel: UILabel!
    @IBOutlet weak var examplesAssualtByLabel: UILabel!
    @IBOutlet weak var placesOfContactBLabel: UILabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup childSexualAbuseLabel
        let childSexualAbuseLabelAttrString = NSMutableAttributedString(string: "Child Sexual Abuse (CSE)", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.childSexualAbuseLabel.attributedText = childSexualAbuseLabelAttrString
        
        // Setup whatIsChildSexualLabel
        let whatIsChildSexualLabelAttrString = NSMutableAttributedString(string: "What is child sexual abuse?\nIt involves forcing or convincing a young person to take part in sexual activities, whether they know what is going on or not.", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 14)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.whatIsChildSexualLabel.attributedText = whatIsChildSexualLabelAttrString
        
        // Setup examplesAssualtByLabel
        let examplesAssualtByLabelAttrString = NSMutableAttributedString(string: "Examples:\n\nAssualt by penetration\n\nNon-penetrative acts (i.e. kissing, touching, masturbating)\n\nWatching sexual acts\n\nLooking at sexual images\n\nEncouraging child to behave in sexually inappropriate ways\n\nGrooming a child\n\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 14)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.examplesAssualtByLabel.attributedText = examplesAssualtByLabelAttrString
        
        // Setup placesOfContactBLabel
        let placesOfContactBLabelAttrString = NSMutableAttributedString(string: "Places of Contact: \n\nBarnardos offer supporrt for children afected and run specialist sessions such as:\n\nTherapy and counselling\nSupport during court proceedings\nSupporting wider family\nIncreasing public awareness", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 14)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.placesOfContactBLabel.attributedText = placesOfContactBLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Youth Corner", sender: nil)
    }
}
