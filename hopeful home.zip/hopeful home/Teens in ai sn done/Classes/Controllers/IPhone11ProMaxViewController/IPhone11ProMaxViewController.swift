//
//  IPhone11ProMaxViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class IPhone11ProMaxViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var rectangleView: UIView!
    @IBOutlet weak var overlayView: UIView!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var callingLabel: UILabel!
    @IBOutlet weak var createCollButtonView: UIView!
    @IBOutlet weak var pressToCallLabel: UILabel!
    @IBOutlet weak var sosLabel: SupernovaLabel!
    private var allGradientLayers: [CAGradientLayer] = []


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.borderColor = UIColor(red: 0.29, green: 0.29, blue: 0.29, alpha: 1).cgColor /* #4A4A4A */
        self.rectangleView.layer.borderWidth = 1
        
        self.rectangleView.layer.cornerRadius = 6
        self.rectangleView.layer.masksToBounds = true
        
        // Setup overlayView
        let overlayViewGradient = CAGradientLayer()
        overlayViewGradient.colors = [UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */, UIColor(red: 0.847, green: 0.847, blue: 0.847, alpha: 0).cgColor /* #D8D8D8 */]
        overlayViewGradient.locations = [0, 1]
        overlayViewGradient.startPoint = CGPoint(x: 0.5, y: 0.778)
        overlayViewGradient.endPoint = CGPoint(x: 0.5, y: 1.511)
        overlayViewGradient.frame = self.overlayView.bounds
        self.overlayView.layer.insertSublayer(overlayViewGradient, at: 0)
        self.allGradientLayers.append(overlayViewGradient)
        
        
        // Setup addressLabel
        let addressLabelAttrString = NSMutableAttributedString(string: "Address: ", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 16)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.addressLabel.attributedText = addressLabelAttrString
        
        // Setup callingLabel
        let callingLabelAttrString = NSMutableAttributedString(string: "Calling: ", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 16)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.callingLabel.attributedText = callingLabelAttrString
        
        // Setup createCollButtonView
        self.createCollButtonView.layer.cornerRadius = 6
        self.createCollButtonView.layer.masksToBounds = true
        
        // Setup pressToCallLabel
        let pressToCallLabelAttrString = NSMutableAttributedString(string: "PRESS TO CALL", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 48)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : -0.55,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.pressToCallLabel.attributedText = pressToCallLabelAttrString
        
        // Setup sosLabel
        let sosLabelAttrString = NSMutableAttributedString(string: "SOS", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 60)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.sosLabel.attributedText = sosLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Layout

    override public func viewDidLayoutSubviews()  {
        super.viewDidLayoutSubviews()
        for layer in self.allGradientLayers {
            layer.frame = layer.superlayer?.frame ?? CGRect.zero
        }
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }
}
