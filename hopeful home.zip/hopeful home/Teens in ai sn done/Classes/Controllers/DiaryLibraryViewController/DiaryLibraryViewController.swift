//
//  DiaryLibraryViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class DiaryLibraryViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var rectangleBlurView: UIView!
    @IBOutlet weak var rectangleTwoBlurView: UIView!
    @IBOutlet weak var rectangleThreeBlurView: UIView!
    @IBOutlet weak var rectangleFourBlurView: UIView!
    @IBOutlet weak var rectangleFiveBlurView: UIView!
    @IBOutlet weak var rectangleSixBlurView: UIView!
    @IBOutlet weak var diaryEntriesLabel: SupernovaLabel!
    @IBOutlet weak var iconButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleBlurView
        self.rectangleBlurView.layer.cornerRadius = 6
        self.rectangleBlurView.layer.masksToBounds = true
        
        // Setup rectangleTwoBlurView
        self.rectangleTwoBlurView.layer.cornerRadius = 6
        self.rectangleTwoBlurView.layer.masksToBounds = true
        
        // Setup rectangleThreeBlurView
        self.rectangleThreeBlurView.layer.cornerRadius = 6
        self.rectangleThreeBlurView.layer.masksToBounds = true
        
        // Setup rectangleFourBlurView
        self.rectangleFourBlurView.layer.cornerRadius = 6
        self.rectangleFourBlurView.layer.masksToBounds = true
        
        // Setup rectangleFiveBlurView
        self.rectangleFiveBlurView.layer.cornerRadius = 6
        self.rectangleFiveBlurView.layer.masksToBounds = true
        
        // Setup rectangleSixBlurView
        self.rectangleSixBlurView.layer.cornerRadius = 6
        self.rectangleSixBlurView.layer.masksToBounds = true
        
        // Setup diaryEntriesLabel
        let diaryEntriesLabelAttrString = NSMutableAttributedString(string: "Diary Entries", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.diaryEntriesLabel.attributedText = diaryEntriesLabelAttrString
        
        // Setup iconButton
        self.iconButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onIconPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push New Diary Entry", sender: nil)
    }
}
