//
//  SafetyPlanOpenViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class SafetyPlanOpenViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var httpsLrsbOrgUkLabel: UILabel!
    @IBOutlet weak var althoughLeavingIsLabel: UILabel!
    @IBOutlet weak var whatIsASafetyPlaLabel: UILabel!
    @IBOutlet weak var accordingToReducinLabel: UILabel!
    @IBOutlet weak var keyPointsLabel: UILabel!
    @IBOutlet weak var ensureThatYouHaveLabel: UILabel!
    @IBOutlet weak var insideSurvivalKitLabel: UILabel!
    @IBOutlet weak var formsOfIdentificatLabel: UILabel!
    @IBOutlet weak var dropupButton: SupernovaButton!
    @IBOutlet weak var safetyContigencyPlLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!
    @IBOutlet weak var thisSectionWillHeLabel: UILabel!
    @IBOutlet weak var rectangleView: UIView!
    @IBOutlet weak var rectangleTwoView: UIView!
    @IBOutlet weak var rectangleThreeView: UIView!
    @IBOutlet weak var rectangleFourView: UIView!
    @IBOutlet weak var rectangleFiveView: UIView!
    @IBOutlet weak var rectangleSixView: UIView!
    @IBOutlet weak var rectangleSevenView: UIView!
    @IBOutlet weak var rectangleEightView: UIView!
    @IBOutlet weak var rectangleNineView: UIView!
    @IBOutlet weak var rectangleTenView: UIView!
    @IBOutlet weak var rectangleElevenView: UIView!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup httpsLrsbOrgUkLabel
        let httpsLrsbOrgUkLabelAttrString = NSMutableAttributedString(string: "https://lrsb.org.uk/uploads/making-a-safety-plan.pdf", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.httpsLrsbOrgUkLabel.attributedText = httpsLrsbOrgUkLabelAttrString
        
        // Setup althoughLeavingIsLabel
        let althoughLeavingIsLabelAttrString = NSMutableAttributedString(string: "\nAlthough leaving is a big courageous thing, statistics show that once a person leaves, the level of danger that they are in doubles because the perpetrator would be angry as they no longer have control over the situation, This may be one of the things stopping victims from leaving.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.althoughLeavingIsLabel.attributedText = althoughLeavingIsLabelAttrString
        
        // Setup whatIsASafetyPlaLabel
        let whatIsASafetyPlaLabelAttrString = NSMutableAttributedString(string: "What is a safety plan?", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.whatIsASafetyPlaLabel.attributedText = whatIsASafetyPlaLabelAttrString
        
        // Setup accordingToReducinLabel
        let accordingToReducinLabelAttrString = NSMutableAttributedString(string: "According to reducingtherisk.org.uk, A safety plan is a tool to assist in identifying options and evaluating them, and can limit the harm brought both to the victim and their children.\n\nVisit:", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.44, green: 0.44, blue: 0.44, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.accordingToReducinLabel.attributedText = accordingToReducinLabelAttrString
        
        // Setup keyPointsLabel
        let keyPointsLabelAttrString = NSMutableAttributedString(string: "Key Points:", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.keyPointsLabel.attributedText = keyPointsLabelAttrString
        
        // Setup ensureThatYouHaveLabel
        let ensureThatYouHaveLabelAttrString = NSMutableAttributedString(string: "Ensure that you have an up to date survival kit\nTry to set aside money, just incase of any emergencies\nHave a safe place to go to, especially if you have children\nAllow a good amount of time to pack, and start packing with the smaller things, so that your perpetrator won’t notice much of a difference\nDiscuss matters  - with friends, family, trusted people, and solicitors in prior to leaving\nIf you do have children, plan for them to come with you, and not afterwards, as this may be putting them in danger.\nConsider all of the options and difficulties so that when it happens, it can be executed as smoothly as possible.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.ensureThatYouHaveLabel.attributedText = ensureThatYouHaveLabelAttrString
        
        // Setup insideSurvivalKitLabel
        let insideSurvivalKitLabelAttrString = NSMutableAttributedString(string: "Inside Survival Kit:", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.insideSurvivalKitLabel.attributedText = insideSurvivalKitLabelAttrString
        
        // Setup formsOfIdentificatLabel
        let formsOfIdentificatLabelAttrString = NSMutableAttributedString(string: "Forms of identification\nBirth certificates\nMoney , cards, bankbooks\nKeys\nDriving licence\nPrescribed medicine\nInsurance documents\nAddress books\nSentimental things\nClothing and toiletries\nAny documentations which are related to the abuse\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.formsOfIdentificatLabel.attributedText = formsOfIdentificatLabelAttrString
        
        // Setup dropupButton
        self.dropupButton.snImageTextSpacing = 10
        
        // Setup safetyContigencyPlLabel
        let safetyContigencyPlLabelAttrString = NSMutableAttributedString(string: "Safety/Contigency Plans", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.safetyContigencyPlLabel.attributedText = safetyContigencyPlLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
        // Setup thisSectionWillHeLabel
        let thisSectionWillHeLabelAttrString = NSMutableAttributedString(string: "This section will help you understand safe routes and contingency plans that different charities and businesses have organised to help victims get leave safely", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 16)!,
            .foregroundColor : UIColor(red: 0.39, green: 0.62, blue: 0.72, alpha: 1),
            .kern : 0.17,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.thisSectionWillHeLabel.attributedText = thisSectionWillHeLabelAttrString
        
        // Setup rectangleView
        self.rectangleView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleView.layer.borderWidth = 1
        
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleTwoView.layer.borderWidth = 1
        
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleThreeView.layer.borderWidth = 1
        
        
        // Setup rectangleFourView
        self.rectangleFourView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleFourView.layer.borderWidth = 1
        
        
        // Setup rectangleFiveView
        self.rectangleFiveView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleFiveView.layer.borderWidth = 1
        
        
        // Setup rectangleSixView
        self.rectangleSixView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleSixView.layer.borderWidth = 1
        
        
        // Setup rectangleSevenView
        self.rectangleSevenView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleSevenView.layer.borderWidth = 1
        
        
        // Setup rectangleEightView
        self.rectangleEightView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleEightView.layer.borderWidth = 1
        
        
        // Setup rectangleNineView
        self.rectangleNineView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleNineView.layer.borderWidth = 1
        
        
        // Setup rectangleTenView
        self.rectangleTenView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleTenView.layer.borderWidth = 1
        
        
        // Setup rectangleElevenView
        self.rectangleElevenView.layer.borderColor = UIColor(red: 0.592, green: 0.592, blue: 0.592, alpha: 1).cgColor /* #979797 */
        self.rectangleElevenView.layer.borderWidth = 1
        
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onViewPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Safety Plan Closed", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helpful Information", sender: nil)
    }
}
